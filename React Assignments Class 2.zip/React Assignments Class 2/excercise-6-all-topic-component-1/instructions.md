### Instructions

This is the running app. You need to modify it to make it modular and do stuff like passing data into 
components, create Stateless Functional Components where appropriate, add state to components where 
needed, updating state functionality if state added to component, and create Controlled Components if needed.

