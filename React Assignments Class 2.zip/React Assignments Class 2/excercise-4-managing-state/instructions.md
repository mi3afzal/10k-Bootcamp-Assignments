### Instructions

You're given a starter template with dummy data.

**Task**: You will be creating a "ADD THE NUMBERS GAME" in which you will display 
three random number and proposed answer on the screen. This proposed number 
could by right answer or could be wrong

You would be creating two buttons to guess the answer 1) True 2) False

By looking at a proposed answer from the screen, user will judge for its correctness
based on that judgement answer could be true or false (in both case user answer can
be count correct or incorrect)

There will be a score counter along with total number of question asked in a following manner

You have answered [user score count] question answered correctly out of total [total question count] questions.

Basic working is also provided in App.js file. 

Please make sure that your application must be modular

This exercise will help you practice almost all the topics we have learned so far specially state management one.
