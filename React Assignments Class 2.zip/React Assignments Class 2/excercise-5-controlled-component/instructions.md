### Instructions

**Task**: This app should reflect all the text you typed in input field. If there is nothing in input box, nothing should be printed to the page.

Remember forms in react component could also controls what happens in that form when user inputs something.

This exercise all about Controlled Components.

