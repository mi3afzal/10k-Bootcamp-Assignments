# Instructions

Change the Components from the assignment you made from class components to functional stateless components
