### Instructions
create an app in modular form and do stuff like passing data into 
components, create Stateless Functional Components where appropriate, add state to components where 
needed, updating state functionality if state added to component, and create Controlled Components if needed.

**Task**: 
App should taker user name as input and show the list below as follows

{user name} has played 0 games.


Make a button and place it somewhere. Text the button "Hide no of games played by user". When user clicks on 
that button text of button changes to "Show no of games user played" and the format of list displayed earlier changes to as follows


{user name} has played * games.

